<?php

namespace boctulus\WooTMHExpress\helpers;

function config(){
    return include __DIR__ . '/../config/config.php';
}
